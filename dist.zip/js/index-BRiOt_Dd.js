import{s as t}from"./Dialog-CjWfKM73.js";import{H as o}from"./index-BENSc4Hk.js";const i=o(t);export{i as D};
