import{aS as l,aT as o,c as u}from"./index-BENSc4Hk.js";const e=Symbol(),s=Symbol(),S=()=>l(s,null),n=a=>{const t=S();o(e,a),o(s,u(()=>(t==null||t.value)&&a.value))};export{S as a,n as u};
